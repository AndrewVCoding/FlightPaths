import java.util.Scanner;
/**
 * Write a description of class MainMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menus
{
    /**
     * This method Displays the main menu and returns the user's choice
     * 
     * @return String
     */
    public String loadMenu()
    {
        Scanner input = new Scanner(System.in);
        System.out.print('\u000C');
        System.out.println("**********************************************************************" + "\n" +
                           "|                  Welcome to Custom Password Maker                  |" + "\n" +
                           "**********************************************************************" + "\n" +
                                                                                                      "\n" +
                           "Please type in which option below you would like to choose"             + "\n" + "\n" +
                           "1) MAKE A PASSWORD"                                                     + "\n" +
                           "3) EXIT PROGRAM"                                                                );
        String choice = input.nextLine();
        return choice;
    }
    /**
     * Displays the PasswordMaker screen, and calls the methods to make a password
     */
    public void makePassword()
    {
        String original = "";
        String passWordFinal = "";
        Scanner input = new Scanner(System.in);
        System.out.print('\u000C');
        System.out.println("**********************************************************************" + "\n" +
                           "|                            PASSSWORD MAKER                         |" + "\n" +
                           "**********************************************************************" + "\n" );
        System.out.println("First, tell me how long you would like your password to be. Keep in \n" +
                           "mind that the length of other parameters will depend on how long you \n"+
                           "want your password to be in the end."                                          );
        System.out.print(">>");
        int length = Integer.parseInt(input.nextLine());
        System.out.print('\u000C');
        System.out.println("**********************************************************************" + "\n" +
                           "|                            PASSSWORD MAKER                         |" + "\n" +
                           "**********************************************************************" + "\n" );
        System.out.println("Now tell me what the source word you want to base your password off of" + "\n" +
                           "will be. Remember, it must be at least " + length/2 + "characters long"        );
        //Get the source word
        boolean properLengthWord = false;               
        do
        {
            System.out.print(">>");
            original = input.nextLine();
        
            if(original.length() >= length/2)
            {
                properLengthWord = true;
            }
            else
            {
                properLengthWord = false;
                System.out.print('\u000C');
                System.out.println("**********************************************************************" + "\n" +
                                   "|                            PASSSWORD MAKER                         |" + "\n" +
                                   "**********************************************************************" + "\n" );
                System.out.println("Remember, your source word must be at least " + length/2
                                 + " characters long.");
            }
        }
        while (properLengthWord == false);
        System.out.print('\u000C');
        System.out.println("**********************************************************************" + "\n" +
                           "|                            PASSSWORD MAKER                         |" + "\n" +
                           "**********************************************************************" + "\n" );
        System.out.println("Great, Your password is: " + passWordFinal);
    }
    /**
     * Displays the settings screen
     */
    public void settings(String[] args)
    {
        System.out.print('\u000C');
        System.out.println("**********************************************************************" + "\n" +
                           "|                              Settings                              |" + "\n" +
                           "**********************************************************************" + "\n" +
                                                                                                      "\n" +
                           "Please type which setting you would like to change"              + "\n" + "\n" +
                           "HASHES will allow you to change how your password is created"           + "\n" +
                           "1) HASHES"                                                                    );
    }
}
