
/**
 * These are the hashes used to generate the password from individual characters coming from the word
 * <p>
 * and number series chosen by the user.
 * 
 * @author Duntorah
 * @version 0.5.0
 */
public class Cryptography
{
    /**
     * Turns a letter into a number
     * @param character
     * @return integer
     */
    public static int charToNum(char letter)
    {
        int number = 0;
        if(letter == 'a'|| letter == 'b' || letter == 'c'|| letter == 'd'|| letter == 'e'|| letter == 'f'|| letter == 'g'|| letter == 'h'|| letter == 'I'|| letter == 'j')
        {
            number = 1;
        }
        if(letter == 'k' || letter == 'l' || letter == 'm' || letter == 'n' || letter == 'o' || letter == 'p')
        {
            number = 2;
        }
        if(letter == 'q')
        {
            number = 0;
        }
        if(letter == 'r')
        {
            number = 1;
        }
        if(letter == 's')
        {
            number = 2;
        }if(letter == 't')
        {
            number = 3;
        }if(letter == 'u')
        {
            number = 4;
        }if(letter == 'v')
        {
            number = 5;
        }if(letter == 'w')
        {
            number = 6;
        }if(letter == 'x')
        {
            number = 7;
        }if(letter == 'y')
        {
            number = 8;
        }if(letter == 'z')
        {
            number = 9;
        }
        return number;
    }
    
    /**
     * Turns a number into a letter
     * @param integer
     * @return character
     */
    public static char numToChar(int number)
    {
        char alpha = 'r';
        if(number == 0)
        {
            alpha = 'q';
        }
        if(number == 1)
        {
            alpha = 'r';
        }
        if(number == 2)
        {
            alpha = 's';
        }
        if(number == 3)
        {
            alpha = 't';
        }
        if(number == 4)
        {
            alpha = 'u';
        }
        if(number == 5)
        {
            alpha = 'v';
        }
        if(number == 6)
        {
            alpha = 'w';
        }
        if(number == 7)
        {
            alpha = 'x';
        }
        if(number == 8)
        {
            alpha = 'y';
        }
        if(number == 9)
        {
            alpha = 'z';
        }
        return alpha;
    }
}
