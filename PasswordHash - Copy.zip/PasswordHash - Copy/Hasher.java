import java.util.Scanner;
/**
 * This program lets the user choose a word and a number sequence, and modifies and combines them to generate a 10 character password with upper case letters, lower case letters, and numbers.
 * 
 * @author Andrew Vaughn
 * @version 1.1.0
 */
public class Hasher
{
    /**
     * This is where all the magic happens.
     * 
     * @param args as String array
     */
    public static void main(String[] args)
    {
        int length = 0;
        char firstChar = 'a';
        char secondChar = 'a';
        char thirdChar = 'a';
        char fourthChar = 'a';
        char fifthChar = 'a';
        
        //First get the user input
        Scanner keyboard = new Scanner(System.in);
        char repeat = 'y';
        boolean lengthCheck = true;
        do
        {
            //Check to make sure the word is at least 5 characters
            do
            {
                System.out.println("Please enter the word you want to turn into a password.");
                String original = keyboard.nextLine();
                original = original.toLowerCase();
                if(original.length() < 5)
                {
                    System.out.println("Sorry, but you must use at least five letters in your seed word");
                    lengthCheck = true;
                }
                if(original.length() >= 5)
                {
                    lengthCheck = false;
                    //Seperate each of the last 5 characters out
                    length = original.length();
                    firstChar = original.charAt(length - 5);
                    secondChar = original.charAt(length - 4);
                    thirdChar = original.charAt(length - 3);
                    fourthChar = original.charAt(length - 2);
                    fifthChar = original.charAt(length - 1);
                    
                    System.out.println("Thank You");
                    
                    lengthCheck = false;
                }
            }
            while (lengthCheck == true);

            //Convert each letter to a number
            int firstNum = AlphaToNum.Hash(firstChar);
            int secondNum = AlphaToNum.Hash(secondChar);
            int thirdNum = AlphaToNum.Hash(thirdChar);
            int fourthNum = AlphaToNum.Hash(fourthChar);
            int fifthNum = AlphaToNum.Hash(fifthChar);
            
            //Rehash those numbers in a reversed order
            firstChar = AlphaToNum.UnHash(fifthNum);
            secondChar = AlphaToNum.UnHash(fourthNum);
            thirdChar = AlphaToNum.UnHash(thirdNum);
            fourthChar = AlphaToNum.UnHash(secondNum);
            fifthChar = AlphaToNum.UnHash(firstNum);
            
            //Ask the user for a 5 number sequence to insert into the hash
            System.out.println("Please enter a string of numbers you want put into the hash. I will use the first 5 digits.");
            String sequence = keyboard.nextLine();
            firstNum = Character.getNumericValue(sequence.charAt(0));
            secondNum = Character.getNumericValue(sequence.charAt(1));
            thirdNum = Character.getNumericValue(sequence.charAt(2));
            fourthNum = Character.getNumericValue(sequence.charAt(3));
            fifthNum = Character.getNumericValue(sequence.charAt(4));
            
            //Hash the new sequence into a String and capitalize every other letter
            char firstCharNew = AlphaToNum.UnHash(firstNum);
            int secondCharNew = AlphaToNum.Hash(firstChar);
            char thirdCharNew = AlphaToNum.UnHash(secondNum);
            int fourthCharNew = AlphaToNum.Hash(secondChar);
            char fifthCharNew = AlphaToNum.UnHash(thirdNum);
            int sixthCharNew = AlphaToNum.Hash(thirdChar);
            char seventhCharNew = AlphaToNum.UnHash(fourthNum);
            int eighthCharNew = AlphaToNum.Hash(fourthChar);
            char ninthCharNew = AlphaToNum.UnHash(fifthNum);
            int tenthCharNew = AlphaToNum.Hash(fifthChar);
        
            firstCharNew = Character.toUpperCase(firstCharNew);
            fifthCharNew = Character.toUpperCase(fifthCharNew);
            ninthCharNew = Character.toUpperCase(ninthCharNew);
    
            //Display the password
            System.out.println("Your new password is: " + firstCharNew + secondCharNew + 
                                                      thirdCharNew + fourthCharNew + 
                                                      fifthCharNew + sixthCharNew + 
                                                      seventhCharNew + eighthCharNew + 
                                                      ninthCharNew + tenthCharNew);
            System.out.println("Would you like to make another password?");
            String doRepeat = keyboard.nextLine();
            doRepeat = doRepeat.toLowerCase();
            repeat = doRepeat.charAt(0);
        }
        while (repeat == 'y');
        System.exit(0);
    }
}
