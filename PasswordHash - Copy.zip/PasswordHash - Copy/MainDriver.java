import java.util.Scanner;
/**
 * Write a description of class MainDriver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class MainDriver
{
    public static void main(String[] args)
    {
        Menus menu = new Menus();
        String choice = menu.loadMenu();
        if (choice == "1")
        {
            menu.makePassword();
        }
    }
}
