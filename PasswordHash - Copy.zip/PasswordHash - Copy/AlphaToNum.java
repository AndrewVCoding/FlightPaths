
/**
 * This class contains the Actual hashes to turn the letters into numbers, and viceversa
 * 
 * @author Andrew Vaughn
 * @version 1.0.0
 */
public class AlphaToNum
{
    /**
     * Turns a letter into a number
     * @param character
     * @return integer
     */
    public static int Hash(char letter)
    {
        int number = 0;
        if(letter == 'a'|| letter == 'b' || letter == 'c'|| letter == 'd'|| letter == 'e'|| letter == 'f'|| letter == 'g'|| letter == 'h'|| letter == 'I'|| letter == 'j')
        {
            number = 1;
        }
        if(letter == 'k' || letter == 'l' || letter == 'm' || letter == 'n' || letter == 'o' || letter == 'p' || letter == 'q')
        {
            number = 2;
        }
        if(letter == 'r')
        {
            number = 1;
        }
        if(letter == 's')
        {
            number = 2;
        }if(letter == 't')
        {
            number = 3;
        }if(letter == 'u')
        {
            number = 4;
        }if(letter == 'v')
        {
            number = 5;
        }if(letter == 'w')
        {
            number = 6;
        }if(letter == 'x')
        {
            number = 7;
        }if(letter == 'y')
        {
            number = 8;
        }if(letter == 'z')
        {
            number = 9;
        }
        return number;
    }
    
    /**
     * Turns a number into a letter
     * @param integer
     * @return character
     */
    public static char UnHash(int number)
    {
        char alpha = 'r';
        if(number == 1)
        {
            alpha = 'r';
        }
        if(number == 2)
        {
            alpha = 's';
        }
        if(number == 3)
        {
            alpha = 't';
        }
        if(number == 4)
        {
            alpha = 'u';
        }
        if(number == 5)
        {
            alpha = 'v';
        }
        return alpha;
    }
}
