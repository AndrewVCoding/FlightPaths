import java.util.Scanner;
/**
 * This is a custom password generator. It allows you to pick a length, a word, and a number series
 * <p>
 * to generate a secure password from. And you don't have to worry about forgetting it, as putting
 * <p>
 * the same parameters into this program will generate the same password everytime!
 * 
 * @author Duntorah 
 * @version 0.6.0
 */
public class Driver
{
    public static void main(String[] args)
    {
        //Main variables for the program
        Scanner input = new Scanner(System.in);
        int finalLength = 10;
        String original = "";
        String numSequence = "";
        String finalPassword = "";
        char rep = 'y';
        
        System.out.println("*********************************************************************");
        System.out.println("|        Hello, and welcome to the Custom Password Generator        |");
        System.out.println("*********************************************************************");
        
        //Ask the user for initial parameters
        do
        {
            System.out.println("     Please tell me how long you would like your password to be.\n" 
                             + "Remember, you have to give a long enough input as well, so don't go\n"
                             + "overboard. But don't go too short either, or it won't be as secure.");
                            /*
                             *      Please tell me how long you would like you password to be.
                             * Remember, you have to give a long enough input as well, so don't go
                             * overboard. But don't go too short either, or it won't be as secure.
                             */
            
            System.out.print(">>");
            finalLength = Integer.parseInt(input.nextLine());
            System.out.println("\n     Great! Now you just have to pick a source word and a " 
                             + "number \nsequence to generate your Password from. First, pick " 
                             + "your word.\nAnd remember to make sure it's at least " + finalLength/2
                             + " characters long, to \nfill up your final password.");
                             /*
                              *      Great! Now you just have to pick a source word and a number
                              * sequence to generate your password from. First, pick your word,
                              * And remember to make sure it's at least 00 characters long, to
                              * fill up your final password.
                              */
                             
            //Get the source word
            boolean properLengthWord = false;               
            do
            {
                System.out.print(">>");
                original = input.nextLine();
            
                if(original.length() >= finalLength/2)
                {
                    properLengthWord = true;
                }
                else
                {
                    properLengthWord = false;
                    System.out.println("Remember, your source word must be at least " + finalLength/2
                                 + " characters long.");
                }
            }
            while (properLengthWord == false);
            
            //If the length is an even number
            if(finalLength % 2 == 0)
            {
                System.out.println("\n     Good job! Now you need to come up with a number sequence"
                                 + " as well. \nJust remember, it should be " + finalLength/2
                                 + " characters long. Any more won't change \nanything, and "
                                 + "any less just won't work.");
                                 /*
                                  *      Good job! Now you need to come up wit a number sequence as well.
                                  * Just remember, it should be 00 characters long. Any more won't change
                                  * anything, and any less just won't work.
                                  */
                             
                //Get the number Sequence
                boolean properLengthNum = false;
                do
                {
                    System.out.print(">>");
                    numSequence = input.nextLine();
            
                    if(numSequence.length() >= finalLength/2)
                    {
                        properLengthNum = true;
                    }
                    else
                    {
                        properLengthNum = false;
                        System.out.println("Remember, your sequence must contain at least " + finalLength/2
                                         + " digits.");
                    }
                }
                while (properLengthNum == false);
            
                System.out.println("\n     Wow, you've really given some great inputs to work with;\n"
                                 + "these'll make an awesome password!");
            
                //reverse the original word and hash the first characters needed
                Hashes Hashes = new Hashes();
                String reverseOriginal = Hashes.reverseHash(original, finalLength/2);
            
                //Now hash the sequence they gave you, and capitalize every other resulting character
                String sequence = Hashes.sequenceHash(numSequence, numSequence.length());
            
                //Now combine the two parts into one password.
                finalPassword = Hashes.meshHash(sequence, reverseOriginal, finalLength/2);
            
                //Choose to either repeat or exit the program
                System.out.println("\n     Great job, you've made a great password! Want to make more?"
                                 + "\n     Choosing \"no\" will exit the program");
                rep = input.nextLine().toLowerCase().charAt(0);
            }
            //if the length is an odd number
            else
            {
                System.out.println("\n     Good job! Now you need to come up with a number sequence"
                                 + " as well. \nJust remember, it should be " + (finalLength/2 + 1)
                                 + " characters long. Any more won't change \nanything, and "
                                 + "any less just won't work.");
                                 /*
                                  *      Good job! Now you need to come up wit a number sequence as well.
                                  * Just remember, it should be 00 characters long. Any more won't change
                                  * anything, and any less just won't work.
                                  */
                             
                //Get the number Sequence
                boolean properLengthNum = false;
                do
                {
                    System.out.print(">>");
                    numSequence = input.nextLine();
            
                    if(numSequence.length() >= (finalLength/2 + 1))
                    {
                        properLengthNum = true;
                    }
                    else
                    {
                        properLengthNum = false;
                        System.out.println("Remember, your sequence must contain at least " + (finalLength/2 + 1)
                                         + " digits.");
                    }
                }
                while (properLengthNum == false);
            
                System.out.println("\n     Wow, you've really given some great inputs to work with;\n"
                                 + "these'll make an awesome password!");
            
                //reverse the original word and hash the first characters needed
                Hashes Hashes = new Hashes();
                String reverseOriginal = Hashes.reverseHash(original, finalLength/2);
            
                //Now hash the sequence they gave you, and capitalize every other resulting character
                String sequence = Hashes.sequenceHash(numSequence, numSequence.length());
            
                //Now combine the two parts into one password.
                finalPassword = Hashes.meshHash(sequence, reverseOriginal, finalLength/2);
            
                //Choose to either repeat or exit the program
                System.out.println("\n     Great job, you've made a great password! Want to make more?"
                                 + "\n     Choosing \"no\" will exit the program");
                rep = input.nextLine().toLowerCase().charAt(0);
            }
        }
        while (rep == 'y');
        System.exit(0);
    }
}
