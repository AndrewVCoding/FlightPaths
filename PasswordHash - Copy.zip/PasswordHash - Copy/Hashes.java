
/**
 * These are all the methods to modify strings
 * 
 * @author Duntorah
 * @version 0.5.0
 */
public class Hashes
{
    /**
     * takes a string input and a target length, and then produces a new, reversed, string
     * <p>
     * with the target length.
     * 
     * @param String
     * @param int
     * @return String
     */
    public String reverseHash(String original, int targetLength)
    {
        int lengthCounter = 1;
        String reverseOriginal = "";
        do
        {
            reverseOriginal = reverseOriginal + Cryptography.charToNum(original.charAt(original.length() - lengthCounter));
            lengthCounter ++;
        }
        while(lengthCounter <= targetLength);
        return reverseOriginal;
    }
    /**
     * returns a String of letters with every other letter capitalized
     * 
     * @param String
     * @param int
     * @return String
     */
    public String sequenceHash(String original, int length)
    {
        String sequence = "";
        int sequenceCount = 0;
        do
        {
            if((sequenceCount % 2) == 0)
            {
                sequence = sequence + Character.toUpperCase(Cryptography.numToChar(Character.getNumericValue(original.charAt(sequenceCount))));
            }
            else
            {
                sequence = sequence + Cryptography.numToChar(Character.getNumericValue(original.charAt(sequenceCount)));
            }
            sequenceCount ++;
        }
        while(sequenceCount < original.length());
        return sequence;
    }
    /**
     * Meshes two Strings together so if you put in "aaaaaa" and "bbbbbb" the result will be "abababababab"
     * <p>
     * And in that example, the count should be '6', the length of each string
     * 
     * @param String - sequence
     * @param String - reversed original
     * @param int
     * @return String
     */
    public String meshHash(String first, String second, int count)
    {
        int finCount = 0;
        String finalPassword = "";
        do
        {
            finalPassword = finalPassword + first.charAt(finCount) + Character.getNumericValue(second.charAt(finCount));
            finCount ++;
        }
        while(finCount < count);
        System.out.println("Congratulations! Your password is: " + finalPassword);
        return finalPassword;
    }
}
